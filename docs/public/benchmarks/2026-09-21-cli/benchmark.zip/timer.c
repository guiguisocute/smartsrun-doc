/* Host-built test helper for disposable OpenWrt VMs; never shipped. */
#define _POSIX_C_SOURCE 200809L
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <sys/un.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

static double now_ms(void) {
    struct timespec t;
    if (clock_gettime(CLOCK_MONOTONIC, &t)) exit(90);
    return t.tv_sec * 1000.0 + t.tv_nsec / 1000000.0;
}

static int rpc_once(const char *method) {
    if (strcmp(method, "status.get") && strcmp(method, "config.get")) return 20;
    int fd = socket(AF_UNIX, SOCK_STREAM, 0);
    if (fd < 0) return 21;
    struct timeval timeout = {30, 0};
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(timeout));
    setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &timeout, sizeof(timeout));
    struct sockaddr_un address = {0};
    address.sun_family = AF_UNIX;
    strcpy(address.sun_path, "/var/run/smart-srun/control.sock");
    if (connect(fd, (struct sockaddr *)&address, sizeof(address))) { close(fd); return 22; }
    char request[256];
    int length = snprintf(request, sizeof(request), "{\"rpc_version\":1,\"request_id\":\"d76-benchmark\",\"method\":\"%s\"}\n", method);
    for (int sent = 0; sent < length;) {
        ssize_t n = write(fd, request + sent, length - sent);
        if (n < 0 && errno == EINTR) continue;
        if (n <= 0) { close(fd); return 23; }
        sent += n;
    }
    char response[1048577];
    size_t used = 0;
    while (used < sizeof(response) - 1) {
        ssize_t n = read(fd, response + used, sizeof(response) - 1 - used);
        if (n < 0 && errno == EINTR) continue;
        if (n <= 0) break;
        used += n;
        if (memchr(response, '\n', used)) break;
    }
    response[used] = 0;
    close(fd);
    return strstr(response, "\"ok\":true") && strstr(response, "\"request_id\":\"d76-benchmark\"") &&
           strchr(response, '\n') ? 0 : 24;
}

int main(int argc, char **argv) {
    if (argc < 4) return 2;
    int warmup = atoi(argv[1]), count = atoi(argv[2]);
    if (warmup < 0 || warmup > 100 || count < 1 || count > 1000) return 2;
    int sink = open("/dev/null", O_RDWR);
    if (sink < 0) return 3;
    for (int i = -warmup; i < count; ++i) {
        double start = now_ms();
        int code;
        if (!strcmp(argv[3], "--rpc")) {
            if (argc != 5) return 2;
            code = rpc_once(argv[4]);
        } else {
        pid_t pid = fork();
        if (pid == 0) {
            alarm(30);
            if (dup2(sink, STDIN_FILENO) < 0 || dup2(sink, STDOUT_FILENO) < 0 ||
                dup2(sink, STDERR_FILENO) < 0) _exit(125);
            close(sink);
            execvp(argv[3], argv + 3);
            _exit(127);
        }
        if (pid < 0) return 4;
        int status;
        while (waitpid(pid, &status, 0) < 0) if (errno != EINTR) return 5;
        code = WIFEXITED(status) ? WEXITSTATUS(status) : 128 + WTERMSIG(status);
        }
        double elapsed = now_ms() - start;
        if (i >= 0) printf("{\"sample\":%d,\"milliseconds\":%.6f,\"exit_code\":%d}\n", i, elapsed, code);
        if (code != 0) return 6;
    }
    close(sink);
    return 0;
}
